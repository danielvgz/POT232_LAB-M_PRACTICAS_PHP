CREATE DATABASE IF NOT EXISTS sistema_mvc;
USE sistema_mvc;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO usuarios (nombre, email, password) 
VALUES ('Administrador', 'admin@correo.com', '$2y$10$8CgDkLgYqS7jK/KkWbptZ.u/gEWh1M7m6mH46w4N4h8u/oEaDby/C'); 
-- La contraseña de prueba arriba es: 123456

