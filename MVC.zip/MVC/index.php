<?php
require_once "controllers/AuthController.php";
require_once "controllers/UserController.php";

$action = $_GET['action'] ?? 'login';

switch ($action) {
    case 'login':
        $auth = new AuthController();
        $auth->login();
        break;
    case 'logout':
        $auth = new AuthController();
        $auth->logout();
        break;
    case 'home':
        $userCtrl = new UserController();
        $userCtrl->index();
        break;
    case 'create':
        $userCtrl = new UserController();
        $userCtrl->create();
        break;
    case 'edit':
        $userCtrl = new UserController();
        $userCtrl->edit();
        break;
    case 'delete':
        $userCtrl = new UserController();
        $userCtrl->delete();
        break;
    default:
        header("Location: index.php?action=login");
        break;
}
