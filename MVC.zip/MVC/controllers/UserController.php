<?php
require_once "config/Database.php";
require_once "models/UserModel.php";

class UserController {
    private $userModel;

    public function __construct() {
        // Protección de Ruta: Validar sesión activa antes de procesar el CRUD
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['user_id'])) {
            header("Location: index.php?action=login");
            exit;
        }

        $database = new Database();
        $db = $database->getConnection();
        $this->userModel = new UserModel($db);
    }

    public function index() {
        $users = $this->userModel->readAll();
        require_once "views/users/index.php";
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->userModel->create($_POST['nombre'], $_POST['email'], $_POST['password']);
            header("Location: index.php?action=home");
        } else {
            require_once "views/users/create.php";
        }
    }

    public function edit() {
        $id = $_GET['id'] ?? null;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->userModel->update($_POST['id'], $_POST['nombre'], $_POST['email']);
            header("Location: index.php?action=home");
        } else {
            $user = $this->userModel->getById($id);
            require_once "views/users/edit.php";
        }
    }

    public function delete() {
        $id = $_GET['id'] ?? null;
        if ($id) {
            $this->userModel->delete($id);
        }
        header("Location: index.php?action=home");
    }
}
