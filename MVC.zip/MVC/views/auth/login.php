<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Iniciar Sesión</title>
    <!-- Bootstrap 3.3.7 CSS -->
    <link rel="stylesheet" href="https://bootstrapcdn.com">
    <style>
        body { background-color: #f5f5f5; padding-top: 40px; }
        .login-panel { max-width: 400px; margin: 0 auto; }
    </style>
</head>
<body>
<div class="container">
    <div class="panel panel-default login-panel">
        <div class="panel-heading">
            <h3 class="panel-title text-center"><strong>Acceso al Sistema</strong></h3>
        </div>
        <div class="panel-body">
            <?php if(isset($error)): ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form action="index.php?action=login" method="POST">
                <div class="form-group">
                    <label for="email">Correo Electrónico</label>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input type="email" class="form-control" id="email" name="email" placeholder="ejemplo@correo.com" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="password">Contraseña</label>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Súper secreto" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Ingresar</button>
            </form>
        </div>
    </div>
</div>

<!-- jQuery y Bootstrap 3 JavaScript -->
<script src="https://googleapis.com"></script>
<script src="https://bootstrapcdn.com"></script>
</body>
</html>
