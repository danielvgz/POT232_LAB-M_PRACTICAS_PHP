<?php require_once 'views/layout.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Panel de Usuarios</title>
    <link rel="stylesheet" href="https://bootstrapcdn.com">
</head>
<body>

<?php renderNavbar(); ?>

<div class="container">
    <div class="row" style="margin-bottom: 20px;">
        <div class="col-md-6">
            <h2>Gestión de Usuarios</h2>
        </div>
        <div class="col-md-6 text-right" style="margin-top: 20px;">
            <a href="index.php?action=create" class="btn btn-success">
                <span class="glyphicon glyphicon-plus"></span> Registrar Nuevo Usuario
            </a>
        </div>
    </div>

    <div class="panel panel-default">
        <div class="panel-heading">Lista de Registros</div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover" style="margin-bottom: 0;">
                <thead>
                    <tr>
                        <th width="80">ID</th>
                        <th>Nombre Completo</th>
                        <th>Email</th>
                        <th width="180" class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($users)): ?>
                        <tr><td colspan="4" class="text-center">No hay usuarios registrados.</td></tr>
                    <?php else: ?>
                        <?php foreach($users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td><?php echo htmlspecialchars($user['nombre']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td class="text-center">
                                <a href="index.php?action=edit&id=<?php echo $user['id']; ?>" class="btn btn-warning btn-xs">
                                    <span class="glyphicon glyphicon-edit"></span> Editar
                                </a>
                                <a href="index.php?action=delete&id=<?php echo $user['id']; ?>" class="btn btn-danger btn-xs" onclick="return confirm('¿Seguro que deseas eliminarlo?')">
                                    <span class="glyphicon glyphicon-trash"></span> Eliminar
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://googleapis.com"></script>
<script src="https://bootstrapcdn.com"></script>
</body>
</html>
