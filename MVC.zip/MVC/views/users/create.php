<?php require_once 'views/layout.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nuevo Usuario</title>
    <link rel="stylesheet" href="https://bootstrapcdn.com">
</head>
<body>

<?php renderNavbar(); ?>

<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><strong>Registrar Nuevo Usuario</strong></h3>
                </div>
                <div class="panel-body">
                    <form action="index.php?action=create" method="POST">
                        <div class="form-group">
                            <label for="nombre">Nombre Completo</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre completo" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Correo Electrónico</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="correo@ejemplo.com" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Contraseña inicial</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Contraseña segura" required>
                        </div>
                        <hr>
                        <div class="text-right">
                            <a href="index.php?action=home" class="btn btn-default">Cancelar</a>
                            <button type="submit" class="btn btn-success">Guardar Registro</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<
