<?php require_once 'views/layout.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar Usuario</title>
    <link rel="stylesheet" href="https://bootstrapcdn.com">
</head>
<body>

<?php renderNavbar(); ?>

<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><strong>Modificar Información</strong></h3>
                </div>
                <div class="panel-body">
                    <form action="index.php?action=edit" method="POST">
                        <!-- ID Oculto necesario para actualizar en base de datos -->
                        <input type="hidden" name="id" value="<?php echo $user['id']; ?>">

                        <div class="form-group">
                            <label for="nombre">Nombre Completo</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo htmlspecialchars($user['nombre']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Correo Electrónico</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        <hr>
                        <div class="text-right">
                            <a href="index.php?action=home" class="btn btn-default">Volver</a>
                            <button type="submit" class="btn btn-warning">Actualizar Cambios</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://googleapis.com"></script>
<script src="https://bootstrapcdn.com"></script>
</body>
</html>
